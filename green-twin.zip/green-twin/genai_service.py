import hashlib
import json
import logging
import time
from datetime import datetime
from typing import Any, Optional

from json_repair import repair_json

import analytics
from analytics import CARBON_KG_PER_KWH, TARIFF_INR_PER_KWH
from config import RECOMMENDATION_CACHE_TTL
from llm import ask_llm
from schemas import (Action, ChatResponse, Recommendation, Totals, TwinTelemetry, ZoneStatus)

log = logging.getLogger("green-twin.service")

# In-memory recommendation TTL cache: state_hash -> (timestamp, Recommendation)
_RECOMMENDATION_CACHE: dict[str, tuple[float, Recommendation]] = {}
CACHE_TTL_S = RECOMMENDATION_CACHE_TTL

RECOMMEND_PROMPT = """You are an energy management engineer and digital twin BMS controller for a smart campus building.
You receive JSON with the room telemetry, zone status, and proposed control actions calculated by the deterministic analytics engine.

Your job is to produce a structured GenAI recommendation matching this EXACT JSON schema:
{
  "timestamp": "ISO-8601 string",
  "room_id": "string",
  "summary": "High-level diagnostic summary explaining biggest energy wastes, total savings, and key control actions (2-3 sentences)",
  "projected_total_power_kw": float,
  "projected_carbon_rate_kgco2_per_hr": float,
  "actions": [
    {
      "zone_id": "string",
      "component": "LIGHTING" or "HVAC",
      "current_value": float,
      "target_value": float,
      "projected_power_saving_w": float,
      "rationale": "Concise technical rationale (1 sentence, max 30 words) quoting specific evidence numbers"
    }
  ]
}

Rules:
- Strictly return valid JSON. Do not add markdown fences or text outside JSON.
- Maintain the numeric values for current_value, target_value, and projected_power_saving_w as provided.
- If no actions are provided, set actions to [] and state that all zones are operating efficiently.
- Write text in __LANG__.
"""

CHAT_PROMPT = """You are the audit assistant of a smart building digital twin.
You receive the live telemetry of one room, the engine's zone_status (optimal =
green, sub_optimal = yellow, energy_waste = red) with the reasons, and the proposed
actions. Answer the user's question using ONLY this data. Name the zones and quote
the numbers. If the data cannot answer the question, say so. Be concise: 2 to 4
sentences. Do not use double quote characters inside text values.
Write the answer in __LANG__.

Return ONLY valid JSON: {"answer": "...", "zones_referenced": ["Zone_A"]}"""


# ----------------------------- helpers -----------------------------
def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def compute_state_hash(t: TwinTelemetry) -> str:
    """Computes a state hash based on:
    1. Total room occupancy
    2. Sum of active fixture wattage (bucketed to absorb <5% micro-fluctuations)
    3. HVAC setpoint delta (setpoint vs measured temp)
    """
    total_occ = sum(int(z.occupancy or 0) for z in t.zone_states.values())

    total_fixture_w = 0.0
    for z in t.zone_states.values():
        fixtures, dim, wpf = analytics.light_info(z)
        w = wpf if wpf is not None else analytics.DEFAULT_WATTS_PER_FIXTURE
        if fixtures is not None and dim is not None:
            total_fixture_w += fixtures * w * (dim / 100.0)

    # Bucketed to absorb minor power fluctuations (< 5%)
    wattage_bucket = round(total_fixture_w / 15.0) * 15.0

    # HVAC delta per zone: round to 0.5 C bins
    hvac_deltas = []
    for zid in sorted(t.zone_states.keys()):
        z = t.zone_states[zid]
        if z.hvac_setpoint_c is not None and z.measured_temp_c is not None:
            delta = round((z.hvac_setpoint_c - z.measured_temp_c) * 2.0) / 2.0
            hvac_deltas.append(f"{zid}:{delta}")
        elif z.hvac_setpoint_c is not None:
            hvac_deltas.append(f"{zid}:sp{round(z.hvac_setpoint_c, 1)}")

    room_id = t.room_metadata.room_id
    state_sig = f"{room_id}|occ:{total_occ}|w:{wattage_bucket}|hvac:{','.join(hvac_deltas)}"
    return hashlib.sha256(state_sig.encode()).hexdigest()


def _extract_json(raw: str) -> dict:
    text = raw.replace("```json", "").replace("```", "").strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1:
        # Check if wrapped in array
        astart, aend = text.find("["), text.rfind("]")
        if astart != -1 and aend > astart:
            arr_text = text[astart:aend + 1]
            try:
                loaded = json.loads(arr_text)
                if isinstance(loaded, list) and loaded and isinstance(loaded[0], dict):
                    return loaded[0]
            except Exception:
                pass
        raise ValueError(f"No JSON object found in model reply: {raw[:150]}")
    text = text[start:end + 1] if end > start else text[start:]
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        fixed = json.loads(repair_json(text))
        if isinstance(fixed, dict):
            return fixed
        if isinstance(fixed, list) and fixed and isinstance(fixed[0], dict):
            return fixed[0]
        raise ValueError("Repaired JSON is not an object")


def _ask_json(system: str, user: str, required: tuple = ()) -> dict:
    last_err = None
    for attempt in range(2):
        try:
            raw = ask_llm(system, user)
            parsed = _extract_json(raw)
            missing = [k for k in required if k not in parsed or parsed[k] is None]
            if missing:
                raise ValueError(f"Incomplete reply, missing required keys: {missing}")
            return parsed
        except Exception as e:
            last_err = e
            log.warning("JSON extraction attempt %d failed: %s", attempt + 1, e)
    raise last_err or RuntimeError("Failed to extract JSON from LLM")


# ----------------------------- /recommend -----------------------------
def _explain_with_ai(t: TwinTelemetry, a: dict, cands: list[dict],
                     proj_kw: float, proj_co2: float, language: str) -> dict:
    """Invokes LLM with the full schema prompt and returns parsed response."""
    payload = {
        "timestamp": t.timestamp or _now(),
        "room_metadata": t.room_metadata.model_dump(),
        "baseline_power_kw": round(a["total_power_w"] / 1000.0, 3),
        "projected_total_power_kw": proj_kw,
        "projected_carbon_rate_kgco2_per_hr": proj_co2,
        "zones": a["zones"],
        "proposed_actions": [
            {
                "id": c["id"],
                "zone_id": c["zone_id"],
                "component": c["component"],
                "current_value": round(c["current"], 1),
                "target_value": round(c["target"], 1),
                "projected_power_saving_w": round(c["saving_w"], 1),
                "evidence": c["evidence"],
            }
            for c in cands
        ],
    }

    return _ask_json(
        RECOMMEND_PROMPT.replace("__LANG__", language),
        json.dumps(payload, default=str),
        required=("summary",),
    )


def recommend(t: TwinTelemetry, language: str = "English") -> Recommendation:
    room_id = t.room_metadata.room_id

    # 1. Check in-memory telemetry TTL cache (anti-spam / debounce)
    state_hash = compute_state_hash(t)
    now = time.time()
    hit = _RECOMMENDATION_CACHE.get(state_hash)
    if hit and (now - hit[0]) < CACHE_TTL_S:
        log.info("Cache hit for room %s (state_hash: %s). Reusing cached recommendation (valid for %ds).",
                 room_id, state_hash[:8], int(CACHE_TTL_S - (now - hit[0])))
        cached_rec = hit[1].model_copy(deep=True)
        cached_rec.timestamp = t.timestamp or _now()
        cached_rec.generated_by = "cache"
        return cached_rec

    # 2. Run deterministic analytics
    a = analytics.analyze_telemetry(t)
    cands = a["candidates"]

    # Compute baseline and projected values
    total_baseline_w = a["total_power_w"]
    total_saving_w = sum(c["saving_w"] for c in cands)
    projected_power_w = max(total_baseline_w - total_saving_w, 0.0)
    projected_total_power_kw = round(projected_power_w / 1000.0, 3)
    projected_carbon_rate_kgco2_per_hr = round(projected_total_power_kw * CARBON_KG_PER_KWH, 3)

    parsed_ai = {}
    source = "rules" if not cands else "fallback"

    # 3. Call GenAI if actions exist, with graceful fallback
    if cands:
        try:
            parsed_ai = _explain_with_ai(
                t, a, cands, projected_total_power_kw, projected_carbon_rate_kgco2_per_hr, language
            )
            source = "ai"
            log.info("GenAI successfully generated recommendation strategy for room %s", room_id)
        except Exception as e:
            log.warning("AI generation failed (%s). Falling back seamlessly to rule-based recommendation.", e)
            source = "fallback"

    # 4. Extract or assemble rationales
    # Map by zone_id + component or action id
    ai_rationales: dict[str, str] = {}
    if isinstance(parsed_ai, dict):
        # Could be rationales dict or actions list
        if "rationales" in parsed_ai and isinstance(parsed_ai["rationales"], dict):
            ai_rationales = parsed_ai["rationales"]
        elif "actions" in parsed_ai and isinstance(parsed_ai["actions"], list):
            for act in parsed_ai["actions"]:
                if isinstance(act, dict):
                    k1 = f"{act.get('zone_id')}_{act.get('component')}"
                    ai_rationales[k1] = act.get("rationale", "")
                    if "id" in act:
                        ai_rationales[str(act["id"])] = act.get("rationale", "")

    actions: list[Action] = []
    for c in cands:
        kw = c["saving_w"] / 1000.0
        lookup_key = f"{c['zone_id']}_{c['component']}"
        rat = (ai_rationales.get(c["id"]) or ai_rationales.get(lookup_key) or "").strip()
        if not rat:
            rat = c["evidence"]

        actions.append(Action(
            zone_id=c["zone_id"],
            component=c["component"],
            current_value=round(c["current"], 1),
            target_value=round(c["target"], 1),
            projected_power_saving_w=round(c["saving_w"], 1),
            rationale=rat,
            unit=c.get("unit"),
            priority=c.get("priority"),
            projected_cost_inr_per_hr=round(kw * TARIFF_INR_PER_KWH, 2),
            projected_co2_kg_per_hr=round(kw * CARBON_KG_PER_KWH, 3),
        ))

    totals = Totals(
        power_saving_w=round(total_saving_w, 1),
        cost_inr_per_hr=round((total_saving_w / 1000.0) * TARIFF_INR_PER_KWH, 2),
        co2_kg_per_hr=round((total_saving_w / 1000.0) * CARBON_KG_PER_KWH, 3),
    )

    # 5. Build summary
    summary = ""
    if isinstance(parsed_ai, dict):
        summary = str(parsed_ai.get("summary", "")).strip()

    if not summary:
        if actions:
            summary = (f"{room_id}: {len(actions)} control action(s) proposed, saving about "
                       f"{totals.power_saving_w:.0f} W (about INR {totals.cost_inr_per_hr:.2f} and "
                       f"{totals.co2_kg_per_hr:.3f} kg CO2 per hr). Largest: {cands[0]['evidence']}.")
        else:
            summary = f"{room_id}: no wasted lighting or HVAC detected; all zones are operating efficiently."

    # 6. Construct strict Recommendation model
    recommendation = Recommendation(
        timestamp=t.timestamp or _now(),
        room_id=room_id,
        summary=summary,
        projected_total_power_kw=projected_total_power_kw,
        projected_carbon_rate_kgco2_per_hr=projected_carbon_rate_kgco2_per_hr,
        actions=actions,
        totals=totals,
        zone_status=[ZoneStatus(zone_id=z["zone_id"], status=z["status"], issues=z["issues"])
                     for z in a["zones"]],
        assumptions=a["assumptions"],
        generated_by=source,
    )

    # 7. Update in-memory TTL cache
    if len(_RECOMMENDATION_CACHE) > 256:
        _RECOMMENDATION_CACHE.clear()
    _RECOMMENDATION_CACHE[state_hash] = (time.time(), recommendation)

    return recommendation


# ----------------------------- /chat -----------------------------
def _mentioned(question: str, ids: list[str]) -> list[str]:
    q = question.lower()
    return [i for i in ids if i.lower() in q or i.lower().replace("_", " ") in q]


def _chat_fallback(question: str, a: dict) -> ChatResponse:
    ids = [z["zone_id"] for z in a["zones"]]
    chosen = _mentioned(question, ids) or ids
    label = {"energy_waste": "flagged red (energy waste)",
             "sub_optimal": "flagged yellow (sub-optimal)", "optimal": "green (optimal)"}
    parts = []
    for z in a["zones"]:
        if z["zone_id"] in chosen:
            parts.append(f"{z['zone_id']} is {label[z['status']]}: "
                         f"{'; '.join(z['issues']) or 'no issues detected'}.")
    return ChatResponse(answer=" ".join(parts), zones_referenced=chosen, generated_by="fallback")


def chat(t: TwinTelemetry, question: str, language: str = "English") -> ChatResponse:
    a = analytics.analyze_telemetry(t)
    payload = {
        "room": t.room_metadata.model_dump(),
        "zone_states": {k: v.model_dump() for k, v in t.zone_states.items()},
        "metrics": t.metrics.model_dump(),
        "zone_status": a["zones"],
        "proposed_actions": [
            {
                "zone_id": c["zone_id"],
                "component": c["component"],
                "current": c["current"],
                "target": c["target"],
                "saving_w": round(c["saving_w"], 1),
                "evidence": c["evidence"],
            }
            for c in a["candidates"]
        ],
        "question": question,
    }
    try:
        p = _ask_json(CHAT_PROMPT.replace("__LANG__", language),
                      json.dumps(payload, default=str),
                      required=("answer",))
        ids = {z["zone_id"] for z in a["zones"]}
        answer = str(p.get("answer", "")).strip()
        if not answer:
            raise ValueError("Empty answer returned by model")
        refs = [z for z in p.get("zones_referenced", []) if z in ids]
        return ChatResponse(answer=answer, zones_referenced=refs, generated_by="ai")
    except Exception as e:
        log.warning("Chat AI failed (%s), using rule-based answer fallback.", e)
        return _chat_fallback(question, a)
