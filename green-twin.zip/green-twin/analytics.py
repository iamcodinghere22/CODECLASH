import os
from typing import Any, Optional

from schemas import TwinTelemetry

# ---- Tunable constants. They are ASSUMPTIONS: check them before presenting. ----
VACANCY_GRACE_MIN = float(os.getenv("VACANCY_GRACE_MIN", 3))        # contract example: empty > 3 min
DEFAULT_WATTS_PER_FIXTURE = float(os.getenv("WATTS_PER_FIXTURE", 40))
COMFORT_SETPOINT_C = 24.0        # target when the zone is occupied (contract example)
VACANT_SETBACK_C = 26.0          # target when the zone is vacant
HVAC_SAVING_PER_DEG = 0.06       # rule of thumb: ~6% of HVAC power per 1 C setpoint change
HVAC_MAX_SAVING_FRACTION = 0.5   # never claim more than 50% of HVAC power from setpoint changes
WARM_TEMP_C = 27.0
CARBON_KG_PER_KWH = float(os.getenv("CARBON_KG_PER_KWH", 0.82))     # from the team contract
TARIFF_INR_PER_KWH = float(os.getenv("TARIFF_INR_PER_KWH", 8.0))    # assumed; set your campus tariff

FIX_KEYS = ("active_fixtures", "active_fixture_count", "fixtures_on", "fixture_count",
            "fixtures", "count", "active")
DIM_KEYS = ("dimming_level", "dimming_pct", "dim_level", "dimming", "level")
WPF_KEYS = ("watts_per_fixture",)


def _num(v: Any) -> Optional[float]:
    if v is None or isinstance(v, bool):
        return None
    return float(v) if isinstance(v, (int, float)) else None


def _f(v: Any, default: float = 0.0) -> float:
    n = _num(v)
    return default if n is None else n


def _first(d: dict, keys) -> Optional[float]:
    for k in keys:
        n = _num(d.get(k))
        if n is not None:
            return n
    return None


def light_info(z):
    """Returns (fixtures, dimming_pct, watts_per_fixture); any can be None."""
    ls = z.light_status
    fixtures = dim = wpf = None
    if isinstance(ls, dict):
        fixtures, dim, wpf = _first(ls, FIX_KEYS), _first(ls, DIM_KEYS), _first(ls, WPF_KEYS)
    elif _num(ls) is not None:
        fixtures = _num(ls)
    if fixtures is not None and dim is None:
        dim = 100.0
    return fixtures, dim, wpf


def _priority(w: float) -> str:
    return "high" if w >= 300 else "medium" if w >= 100 else "low"


def analyze_telemetry(t: TwinTelemetry) -> dict:
    assumptions: list[str] = []

    def note(s: str):
        if s not in assumptions:
            assumptions.append(s)

    cands: list[dict] = []
    zones: list[dict] = []

    for zid, z in t.zone_states.items():
        occ = int(_f(z.occupancy))
        vacant = occ == 0
        fixtures, dim, wpf = light_info(z)
        power, wasted = _f(z.power_draw_w), _f(z.wasted_power_w)
        vm = z.vacant_minutes
        vac_txt = f" for {vm:g} min" if vm is not None else ""
        grace_ok = vm is None or vm >= VACANCY_GRACE_MIN
        issues: list[str] = []
        zone_cands: list[dict] = []

        # current lighting power estimate (fixtures x watts x dimming)
        light_now = None
        if fixtures is not None:
            w = wpf if wpf is not None else DEFAULT_WATTS_PER_FIXTURE
            light_now = fixtures * w * (dim or 0) / 100
            if power > 0:
                light_now = min(light_now, power)

        if vacant and not grace_ok:
            issues.append(f"{zid} is vacant{vac_txt}, still inside the {VACANCY_GRACE_MIN:g} min "
                          f"grace period, so no switch-off yet")

        # ---------------- LIGHTING ----------------
        light_saving = 0.0
        if vacant and grace_ok and fixtures and dim and dim > 0:
            light_saving = light_now
            if wasted > 0:
                light_saving = min(light_saving, wasted)
            if wpf is None:
                note(f"Lighting power assumed {DEFAULT_WATTS_PER_FIXTURE:g} W per fixture (not provided)")
            ev = (f"{zid} has 0 occupants{vac_txt} but {fixtures:g} fixtures are at {dim:g}% "
                  f"(about {light_saving:.0f} W)")
            zone_cands.append(dict(zone_id=zid, component="LIGHTING", unit="percent",
                                   current=dim, target=0.0, saving_w=light_saving, evidence=ev))
            issues.append(ev)

        # ---------------- HVAC ----------------
        sp = z.hvac_setpoint_c
        if sp is not None:
            hvac_w = max(power - (light_now or 0.0), 0.0)
            target, ev = None, ""
            mt = f", measured {z.measured_temp_c:g} C" if z.measured_temp_c is not None else ""
            if vacant and grace_ok and sp < VACANT_SETBACK_C:
                target = VACANT_SETBACK_C
                ev = f"{zid} is vacant{vac_txt} but HVAC is set to {sp:g} C{mt}"
            elif not vacant and sp < COMFORT_SETPOINT_C:
                target = COMFORT_SETPOINT_C
                ev = (f"{zid} has {occ} occupants and a {sp:g} C setpoint, below the "
                      f"{COMFORT_SETPOINT_C:g} C comfort target{mt}")
            if target is not None:
                frac = min(HVAC_SAVING_PER_DEG * (target - sp), HVAC_MAX_SAVING_FRACTION)
                saving = hvac_w * frac
                if vacant and wasted > 0:
                    saving = min(saving, max(wasted - light_saving, 0.0))  # no double counting
                note(f"HVAC saving estimated at {HVAC_SAVING_PER_DEG * 100:g}% of HVAC power per 1 C "
                     f"of setpoint change (rule of thumb, capped at {HVAC_MAX_SAVING_FRACTION * 100:g}%)")
                if power <= 0:
                    ev += " (no power data, saving cannot be estimated)"
                zone_cands.append(dict(zone_id=zid, component="HVAC", unit="celsius",
                                       current=sp, target=target, saving_w=saving, evidence=ev))
                issues.append(ev)

        mt_val = z.measured_temp_c
        if not vacant and mt_val is not None and mt_val > WARM_TEMP_C:
            issues.append(f"{zid} measures {mt_val:g} C while occupied; comfort first, "
                          f"no energy cut proposed")

        if vacant and grace_ok and (wasted > 0 or zone_cands):
            status = "energy_waste"
        elif zone_cands or issues:
            status = "sub_optimal"
        else:
            status = "optimal"

        cands.extend(zone_cands)
        zones.append(dict(zone_id=zid, status=status, occupancy=occ, issues=issues,
                          power_draw_w=power, wasted_power_w=wasted))

    cands.sort(key=lambda c: -c["saving_w"])
    for i, c in enumerate(cands, 1):
        c["id"] = f"A{i}"
        c["priority"] = _priority(c["saving_w"])

    total_w = _f(t.metrics.total_power_kw) * 1000 or sum(z["power_draw_w"] for z in zones)
    return {"candidates": cands, "zones": zones, "assumptions": assumptions,
            "total_power_w": round(total_w, 1)}