import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import SERVICE_NAME
from genai_service import chat, recommend
from schemas import ChatRequest, ChatResponse, Recommendation, TwinTelemetry

# Structured console logging configuration
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("green-twin")

app = FastAPI(title="Green Building Twin: GenAI Strategy Agent (A)")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)


@app.get("/")
def root():
    """Root status / health check endpoint for browser visits and service probes."""
    return {"status": "healthy", "service": SERVICE_NAME}


@app.get("/api/health")
def health():
    return {"status": "ok", "service": SERVICE_NAME}


@app.post("/api/agent/recommend", response_model=Recommendation, response_model_exclude_none=True)
def agent_recommend(telemetry: TwinTelemetry, minimal: bool = False, language: str = "English"):
    """Twin Telemetry in -> GenAI Recommendation out.
    Returns strictly formatted recommendation schema compatible with Digital Twin module.
    ?minimal=true returns ONLY the contract fields (no optional extras).
    """
    room_id = telemetry.room_metadata.room_id
    total_power = telemetry.metrics.total_power_kw or 0.0
    wasted_kwh = telemetry.metrics.cumulative_wasted_kwh or 0.0
    log.info("INBOUND [recommend] Room: %s | Zones: %d | Power: %.2f kW | Wasted: %.2f kWh",
             room_id, len(telemetry.zone_states), total_power, wasted_kwh)

    rec = recommend(telemetry, language)

    if minimal:
        for x in rec.actions:
            x.unit = x.priority = x.projected_cost_inr_per_hr = x.projected_co2_kg_per_hr = None
        rec.totals = rec.zone_status = rec.assumptions = rec.generated_by = None

    saving_w = sum(x.projected_power_saving_w for x in rec.actions)
    log.info("OUTBOUND [recommend] Room: %s | Source: %s | Actions: %d | Saving: %.1f W | Proj Power: %.3f kW | Proj CO2: %.3f kg/h",
             room_id, rec.generated_by or "ai", len(rec.actions), saving_w,
             rec.projected_total_power_kw, rec.projected_carbon_rate_kgco2_per_hr)

    for idx, act in enumerate(rec.actions, 1):
        log.info("  Action #%d [%s %s]: %.1f -> %.1f (Saving: %.1f W) | Rationale: %s",
                 idx, act.zone_id, act.component, act.current_value, act.target_value,
                 act.projected_power_saving_w, act.rationale)

    return rec


@app.post("/api/agent/chat", response_model=ChatResponse)
def agent_chat(body: ChatRequest):
    """Audit interface: 'Why is Zone A flagged red?' -> telemetry-backed answer."""
    room_id = body.telemetry.room_metadata.room_id
    log.info("INBOUND [chat] Room: %s | Question: %s", room_id, body.question)

    resp = chat(body.telemetry, body.question, body.language)

    log.info("OUTBOUND [chat] Room: %s | Source: %s | Answer: %s",
             room_id, resp.generated_by, resp.answer[:120] + "..." if len(resp.answer) > 120 else resp.answer)
    return resp