import json
import requests

BASE = "http://localhost:8000"
t = json.load(open("mock_telemetry.json"))

r = requests.post(f"{BASE}/api/agent/recommend", json=t)
print(json.dumps(r.json(), indent=2))

r = requests.post(f"{BASE}/api/agent/chat",
                  json={"telemetry": t, "question": "Why is Zone_B flagged red?"})
print(json.dumps(r.json(), indent=2))


