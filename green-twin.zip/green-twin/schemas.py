from typing import Any, Literal, Optional
from pydantic import BaseModel, ConfigDict, Field


# ===================== INPUT: Twin Telemetry Schema (N -> A) =====================
class RoomMetadata(BaseModel):
    model_config = ConfigDict(extra="allow")
    room_id: str
    capacity: Optional[float] = None
    area_sqft: Optional[float] = None


class ZoneState(BaseModel):
    model_config = ConfigDict(extra="allow")
    occupancy: Optional[float] = 0
    # Contract: active fixture count + dimming level (0-100) or dict/number
    light_status: Any = None
    hvac_setpoint_c: Optional[float] = None
    measured_temp_c: Optional[float] = None
    power_draw_w: Optional[float] = None
    wasted_power_w: Optional[float] = None
    vacant_minutes: Optional[float] = None


class Metrics(BaseModel):
    model_config = ConfigDict(extra="allow")
    total_power_kw: Optional[float] = None
    cumulative_wasted_kwh: Optional[float] = None
    carbon_rate_kgco2_per_hr: Optional[float] = None


class TwinTelemetry(BaseModel):
    model_config = ConfigDict(extra="allow")
    timestamp: Optional[str] = None
    room_metadata: RoomMetadata
    zone_states: dict[str, ZoneState]
    metrics: Metrics = Field(default_factory=Metrics)


class ChatRequest(BaseModel):
    telemetry: TwinTelemetry
    question: str
    language: str = "English"


# ===================== OUTPUT: GenAI Recommendation Schema (A -> N) =====================
class Action(BaseModel):
    model_config = ConfigDict(extra="allow")
    zone_id: str
    component: Literal["LIGHTING", "HVAC"]
    current_value: float
    target_value: float
    projected_power_saving_w: float
    rationale: str
    # Optional extras
    unit: Optional[str] = None
    priority: Optional[Literal["high", "medium", "low"]] = None
    projected_cost_inr_per_hr: Optional[float] = None
    projected_co2_kg_per_hr: Optional[float] = None


class ZoneStatus(BaseModel):
    model_config = ConfigDict(extra="allow")
    zone_id: str
    status: Literal["optimal", "sub_optimal", "energy_waste"]
    issues: list[str] = Field(default_factory=list)


class Totals(BaseModel):
    model_config = ConfigDict(extra="allow")
    power_saving_w: float = 0.0
    cost_inr_per_hr: float = 0.0
    co2_kg_per_hr: float = 0.0


class Recommendation(BaseModel):
    model_config = ConfigDict(extra="allow")
    timestamp: str
    room_id: str
    summary: str
    projected_total_power_kw: float
    projected_carbon_rate_kgco2_per_hr: float
    actions: list[Action] = Field(default_factory=list)
    # Optional diagnostic metadata
    totals: Optional[Totals] = None
    zone_status: Optional[list[ZoneStatus]] = None
    assumptions: Optional[list[str]] = None
    generated_by: Optional[Literal["ai", "rules", "fallback", "cache"]] = None


class ChatResponse(BaseModel):
    model_config = ConfigDict(extra="allow")
    answer: str
    zones_referenced: list[str] = Field(default_factory=list)
    generated_by: Literal["ai", "fallback"] = "ai"