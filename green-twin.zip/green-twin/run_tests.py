import json
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)
t = json.load(open("mock_telemetry.json"))

print("\n=== TEST 1: Root Health Check ===")
r_root = client.get("/")
print("Status:", r_root.status_code)
print("Response:", r_root.json())
assert r_root.status_code == 200
assert r_root.json()["status"] == "healthy"

print("\n=== TEST 2: Initial Recommend (External LLM Call) ===")
r1 = client.post("/api/agent/recommend", json=t)
print("Status:", r1.status_code)
d1 = r1.json()
print("Source:", d1.get("generated_by"))
print("Room ID:", d1.get("room_id"))
print("Summary:", d1.get("summary"))
print("Projected Power (kW):", d1.get("projected_total_power_kw"))
print("Projected Carbon (kg/h):", d1.get("projected_carbon_rate_kgco2_per_hr"))
print("Actions count:", len(d1.get("actions", [])))
assert r1.status_code == 200
assert d1["room_id"] == "Lab_302"
assert "projected_total_power_kw" in d1
assert "projected_carbon_rate_kgco2_per_hr" in d1
assert len(d1["actions"]) > 0

print("\n=== TEST 3: Repeated Recommend (Cache Debounce / Anti-Spam) ===")
r2 = client.post("/api/agent/recommend", json=t)
print("Status:", r2.status_code)
d2 = r2.json()
print("Source:", d2.get("generated_by"))
assert r2.status_code == 200
assert d2.get("generated_by") == "cache", f"Expected cache, got {d2.get('generated_by')}"

print("\n=== TEST 4: Minimal Contract (?minimal=true) ===")
r3 = client.post("/api/agent/recommend?minimal=true", json=t)
d3 = r3.json()
print("Keys at root:", sorted(list(d3.keys())))
print("Keys in action 0:", sorted(list(d3["actions"][0].keys())))
assert set(d3.keys()) == {
    "timestamp", "room_id", "summary", "projected_total_power_kw",
    "projected_carbon_rate_kgco2_per_hr", "actions"
}
assert set(d3["actions"][0].keys()) == {
    "zone_id", "component", "current_value", "target_value",
    "projected_power_saving_w", "rationale"
}

print("\n=== TEST 5: Chat Endpoint ===")
r4 = client.post("/api/agent/chat", json={
    "telemetry": t,
    "question": "Why is Zone_B flagged red?"
})
print("Status:", r4.status_code)
d4 = r4.json()
print("Answer:", d4.get("answer"))
print("Zones referenced:", d4.get("zones_referenced"))
print("Source:", d4.get("generated_by"))
assert r4.status_code == 200
assert len(d4.get("answer", "")) > 0

print("\n=== TEST 6: Simulated Failure / Zero-Crash Fallback Test ===")
import unittest.mock
import genai_service
genai_service._RECOMMENDATION_CACHE.clear()

with unittest.mock.patch("genai_service.ask_llm", side_effect=RuntimeError("Simulated 429 RateLimit")):
    r_fb = client.post("/api/agent/recommend", json=t)
    print("Fallback Recommend Status:", r_fb.status_code)
    d_fb = r_fb.json()
    print("Fallback Source:", d_fb.get("generated_by"))
    print("Fallback Proj Power:", d_fb.get("projected_total_power_kw"))
    print("Fallback Proj Carbon:", d_fb.get("projected_carbon_rate_kgco2_per_hr"))
    print("Fallback Actions:", len(d_fb.get("actions", [])))
    assert r_fb.status_code == 200
    assert d_fb.get("generated_by") == "fallback"
    assert d_fb.get("projected_total_power_kw") is not None
    assert d_fb.get("projected_carbon_rate_kgco2_per_hr") is not None

    r_chat_fb = client.post("/api/agent/chat", json={
        "telemetry": t,
        "question": "Why is Zone_B flagged red?"
    })
    print("Fallback Chat Status:", r_chat_fb.status_code)
    print("Fallback Chat Source:", r_chat_fb.json().get("generated_by"))
    assert r_chat_fb.status_code == 200
    assert r_chat_fb.json().get("generated_by") == "fallback"

print("\n=== ALL TESTS (INCLUDING FALLBACK RESILIENCE) PASSED! ===")
