import logging
import os
import time
from typing import Optional
from openai import OpenAI, APIError, RateLimitError, APIConnectionError, InternalServerError, NotFoundError
from config import LLM_MODEL, LLM_API_KEY, LLM_BASE_URL

log = logging.getLogger("green-twin.llm")

MODEL = LLM_MODEL or "gemini-3.1-flash-lite"
# Resilient fallback models if the primary model is deprecated (404) or unavailable (503)
FALLBACK_MODELS = ["gemini-3.1-flash-lite", "gemini-flash-lite-latest", "gemini-3.8-flash"]

_client = OpenAI(
    api_key=LLM_API_KEY,
    base_url=LLM_BASE_URL or None,
)


def ask_llm(system: str, content: str, max_tokens: int = 8000) -> str:
    """Sends prompt to LLM with exponential backoff retry on 429/503 errors and auto-recovery.
    
    Attempts up to 3 times with 2s and 4s delays for transient errors (429 RESOURCE_EXHAUSTED, 503 UNAVAILABLE).
    If a model returns 404 (e.g. deprecated gemini-2.5-flash), falls back to available active models.
    """
    max_retries = 3
    backoff_delays = [2, 4]  # Delay before attempt 2: 2s, before attempt 3: 4s
    last_exception: Optional[Exception] = None
    active_model = MODEL

    for attempt in range(1, max_retries + 1):
        try:
            log.info("Dispatching LLM call (model: %s, attempt %d/%d)", active_model, attempt, max_retries)
            resp = _client.chat.completions.create(
                model=active_model,
                max_tokens=max_tokens,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": content},
                ],
            )
            content_out = resp.choices[0].message.content or ""
            return content_out

        except NotFoundError as e:
            # Handle deprecated model IDs (e.g. 2.5-flash / 1.5-flash returning 404)
            log.warning("Model '%s' returned 404 Not Found: %s", active_model, e)
            for alt_model in FALLBACK_MODELS:
                if alt_model != active_model:
                    log.info("Switching to active alternate model '%s'", alt_model)
                    active_model = alt_model
                    break
            last_exception = e

        except (RateLimitError, APIConnectionError, InternalServerError) as e:
            last_exception = e
            status = getattr(e, "status_code", None)
            log.warning("LLM transient failure on attempt %d/%d (status %s): %s",
                        attempt, max_retries, status or type(e).__name__, e)
            if attempt < max_retries:
                delay = backoff_delays[attempt - 1]
                log.info("Applying exponential backoff: waiting %d seconds before retry...", delay)
                time.sleep(delay)

        except APIError as e:
            msg = str(e).lower()
            status = getattr(e, "status_code", None)
            is_transient = (
                status in (429, 503)
                or "429" in msg
                or "503" in msg
                or "resource_exhausted" in msg
                or "unavailable" in msg
            )
            if is_transient:
                last_exception = e
                log.warning("LLM API error %s on attempt %d/%d: %s", status or "transient", attempt, max_retries, e)
                if attempt < max_retries:
                    delay = backoff_delays[attempt - 1]
                    log.info("Applying exponential backoff: waiting %d seconds before retry...", delay)
                    time.sleep(delay)
            else:
                log.error("Non-transient LLM error on attempt %d/%d: %s", attempt, max_retries, e)
                raise e

        except Exception as e:
            msg = str(e).lower()
            if "429" in msg or "503" in msg or "resource_exhausted" in msg or "unavailable" in msg:
                last_exception = e
                log.warning("LLM rate-limit / availability error on attempt %d/%d: %s", attempt, max_retries, e)
                if attempt < max_retries:
                    delay = backoff_delays[attempt - 1]
                    log.info("Applying exponential backoff: waiting %d seconds before retry...", delay)
                    time.sleep(delay)
            else:
                log.error("Unhandled exception during LLM execution: %s", e)
                raise e

    if last_exception:
        log.error("All %d LLM attempts exhausted. Raising exception for fallback handling.", max_retries)
        raise last_exception

    raise RuntimeError("LLM request failed after retries")